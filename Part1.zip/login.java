/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project.part1;

/**
 *
 * @author mohla
 */import java.util.Scanner;

public class login {

    private String storedUsername;
    private String storedPassword;

    // Constructor to receive registered details
    public login(String username, String password) {
        this.storedUsername = username;
        this.storedPassword = password;
    }

    // Method to verify login
    public boolean checkLogin(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    // Main method to test login
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Simulated registered user (from your previous program)
        String registeredUsername = "_ab1";
        String registeredPassword = "Pass@123";

        Login login = new Login(registeredUsername, registeredPassword);

        System.out.println("=== LOGIN ===");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (login.checkLogin(username, password)) {
            System.out.println("Login successful! Welcome back.");
        } else {
            System.out.println("Login failed! Username or password incorrect.");
        }
    }
}
